<?php
include_once 'confi.php';
?>
 
<?php
 
$title = $_POST['title'];
$description = $_POST['description'];
 
$sql = "INSERT INTO ads(title, description) VALUES('$title','$description')";
 
if(mysqli_query($conn, $sql)){
    echo "<script>alert('Records added successfully!!')</script>";
	
}
else{
    echo "<script>alert('Error: Records not added!')</script>";
}

mysqli_close($conn);
 
?>